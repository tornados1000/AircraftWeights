<?php

return [
    'name' => 'AircraftWeights',
];
